// LN DO CORTE V8 - Edge Function
// Recebe o webhook de INSERT da tabela appointments e envia a mensagem
// para os números salvos em settings. As credenciais ficam em Secrets.
import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Content-Type': 'application/json',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const payload = await req.json();
    const record = payload?.record;
    if (!record?.name || !record?.date || !record?.time) {
      return new Response(JSON.stringify({ ok:false, error:'payload sem agendamento' }), { status:400, headers:cors });
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    const { data: settings, error } = await supabase.from('settings').select('owner_phones').eq('id',1).single();
    if (error) throw error;
    const phones = Array.isArray(settings?.owner_phones) ? settings.owner_phones : [];
    if (!phones.length) return new Response(JSON.stringify({ok:true, sent:0, reason:'nenhum número cadastrado'}), {headers:cors});

    const message = `${record.name} agendou um horário para ${String(record.date).split('-').reverse().join('/')} às ${String(record.time).slice(0,5)}. Forma de pagamento: ${record.payment}.`;
    const provider = Deno.env.get('MESSAGE_PROVIDER') || 'twilio-whatsapp';
    if (provider !== 'twilio-whatsapp') throw new Error('MESSAGE_PROVIDER não suportado');

    const sid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const token = Deno.env.get('TWILIO_AUTH_TOKEN');
    const from = Deno.env.get('TWILIO_WHATSAPP_FROM');
    const contentSid = Deno.env.get('TWILIO_CONTENT_SID');
    if (!sid || !token || !from) throw new Error('Configure TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN e TWILIO_WHATSAPP_FROM nos Secrets.');

    let sent = 0;
    for (const raw of phones) {
      const to = String(raw).replace(/\s+/g,'');
      const params = new URLSearchParams();
      params.set('From', from);
      params.set('To', to.startsWith('whatsapp:') ? to : `whatsapp:${to}`);
      if (contentSid) {
        params.set('ContentSid', contentSid);
        params.set('ContentVariables', JSON.stringify({1: String(record.date).split('-').reverse().join('/'), 2: String(record.time).slice(0,5), 3: record.name, 4: record.payment}));
      } else {
        params.set('Body', message);
      }
      const auth = btoa(`${sid}:${token}`);
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method:'POST',
        headers:{'Authorization':`Basic ${auth}`,'Content-Type':'application/x-www-form-urlencoded'},
        body:params.toString()
      });
      if (!r.ok) throw new Error(`Twilio respondeu ${r.status}: ${await r.text()}`);
      sent++;
    }
    return new Response(JSON.stringify({ok:true,sent}), {headers:cors});
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ok:false,error:String(e?.message||e)}), {status:500,headers:cors});
  }
});
