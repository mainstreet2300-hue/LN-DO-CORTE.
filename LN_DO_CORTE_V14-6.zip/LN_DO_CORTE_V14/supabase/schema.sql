-- LN DO CORTE V11 - banco online
create extension if not exists pgcrypto;

create table if not exists public.settings (
  id integer primary key default 1 check (id = 1),
  price numeric(10,2) not null default 10,
  instagram text not null default '',
  owner_phones jsonb not null default '[]'::jsonb,
  finance_reset_at timestamptz,
  updated_at timestamptz not null default now()
);
insert into public.settings (id) values (1) on conflict (id) do nothing;
alter table public.settings add column if not exists finance_reset_at timestamptz;
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  date date not null,
  time time not null,
  payment text not null check (payment in ('Pix','Cartão','Dinheiro')),
  status text not null default 'scheduled' check (status in ('scheduled','done','cancelled')),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
alter table public.appointments add column if not exists completed_at timestamptz;
create unique index if not exists appointments_date_time_unique on public.appointments(date,time);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  text text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.settings enable row level security;
alter table public.appointments enable row level security;
alter table public.notifications enable row level security;

-- Público: pode ler somente o preço/Instagram e criar agendamentos.
drop policy if exists "public read settings" on public.settings;
create policy "public read settings" on public.settings for select using (true);

drop policy if exists "public insert appointments" on public.appointments;
create policy "public insert appointments" on public.appointments for insert with check (true);

-- Dono autenticado: gerencia tudo.
drop policy if exists "owner read appointments" on public.appointments;
create policy "owner read appointments" on public.appointments for select to authenticated using (true);
drop policy if exists "owner update appointments" on public.appointments;
create policy "owner update appointments" on public.appointments for update to authenticated using (true) with check (true);

drop policy if exists "owner read notifications" on public.notifications;
create policy "owner read notifications" on public.notifications for select to authenticated using (true);
drop policy if exists "owner update notifications" on public.notifications;
create policy "owner update notifications" on public.notifications for update to authenticated using (true) with check (true);

-- O dono precisa editar settings pelo painel autenticado.
drop policy if exists "owner update settings" on public.settings;
create policy "owner update settings" on public.settings for update to authenticated using (true) with check (true);
drop policy if exists "owner insert settings" on public.settings;
create policy "owner insert settings" on public.settings for insert to authenticated with check (true);

-- Gatilho que cria a notificação interna sempre que entra um agendamento.
create or replace function public.create_booking_notification()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications(title,text)
  values ('Novo agendamento!',
          NEW.name || ' agendou um horário para ' || to_char(NEW.date,'DD/MM/YYYY') || ' às ' || to_char(NEW.time,'HH24:MI') || '. Forma de pagamento: ' || NEW.payment || '.');
  return NEW;
end;
$$;

drop trigger if exists trg_booking_notification on public.appointments;
create trigger trg_booking_notification after insert on public.appointments
for each row execute function public.create_booking_notification();
